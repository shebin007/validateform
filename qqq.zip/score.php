<?php
    require_once "conn.php";
    $name = $_POST['name'];
    $mail = $_POST['email'];
    $phn = $_POST['mob'];
    $ph = $_POST['physics'];
    $ch = $_POST['chemistry'];
    $ma = $_POST['maths'];
    $cs = $_POST['cse'];
    $la = $_POST['lang'];
    $eng = $_POST['eng'];
    $avg = ($ph + $ch + $ma + $cs + $la + $eng )/1200 ;
    $avgpcm = ($ph + $ch + $ma )/600;

    $query = "INSERT INTO student (email,phno,phy,che,ma,lang,eng,cse,avg,avgpcm,name)"."VALUES (:eml,:phno,:phy,:ch,:mat,:lan,:en,:cse,:avg,:avgpcm,:name);";
    $statement = $db->prepare($query); 
    $statement->execute(  
        array(  
             'eml'     =>    $_POST["email"],
             'phno'     =>    $_POST["mob"],
             'phy'     =>     $_POST["physics"],
             'ch'     =>     $_POST["chemistry"],
             'mat'     =>     $_POST["maths"],
             'lan'     =>     $_POST["cse"],
             'en'     =>     $_POST["lang"],
             'cse'     =>     $_POST["eng"],
             'avg'     =>     $avg,
             'avgpcm'     =>     $avgpcm,
             'name'     =>     $_POST["name"]
        )  
   ); 
    echo $avg *100 ."%";
    if($avgpcm > 0.9 ){
        echo "<br>  sucesfully achived a 100% tution fee scholarship <br> <a href=index.html>Go Back</a>";
    }

    elseif($avgpcm > 0.85){
        echo "<br> you are succesfully eligible for 55% fee scholar<br> <a href=index.html>Go Back</a>";
    }
    elseif($avgpcm > 0.80){
        echo "<br> you are succesfully eligible for 50% fee scholar<br> <a href=index.html>Go Back</a>";
    }
    elseif($avgpcm > 0.75){
        echo "<br> you are succesfully eligible for 50% fee scholar <br> <a href=index.html>Go Back</a>";
    }
    elseif($avg > 0.7){
        echo "<br> you are succesfully eligible for 50% fee scholar<br> <a href=index.html>Go Back</a>";
    }
    elseif($avg > 0.6){
        echo "<br> you are succesfully eligible for 30% fee scholar<br> <a href=index.html>Go Back</a>";
    }
    else{
        echo "<br>Sorry you are not eligible for scholarship scheme";
    }   
?>